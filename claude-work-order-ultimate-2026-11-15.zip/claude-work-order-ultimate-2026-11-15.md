# Claude work order — NostalGem: THE COMPLETE ORDER (v1.19 scope)

**For Claude, from Mitchel via Nova — 2026-11-15.** Hand Claude **this one file only**. **Revised 2026-11-15 ~21:53 — mission + funding principle folded in.**

**Mission (Mitchel's words, 2026-11-15): the app is "to provide things to the people, by the people."** It stays free — no paywalls, no ads for revenue, no in-app purchases, no monetization features. If anyone ever wants to support it, the Internet Archive receives funds FIRST, before any coffee/tip money — and Mitchel personally expects and wants $0 from it.

**This file supersedes the three 2026-11-14 orders** — `claude-work-order-direct-links-2026-11-14.md`, `local-hub-work-order-2026-11-14.md`, and `claude-work-order-boxsets-sound-packs-2026-11-14.md`. Everything in those three is in here, updated and de-duplicated. Do not work from the old files; they are kept only as history. If anything in this file conflicts with an old file, this file wins.

Repo: https://github.com/TheUpDoge/Nostalgem (public). Main is **1.18.1, live on the web** (crystal-TV start-up, Video Club genre rows, Send to TV, phone Mouse page, 4:3 mode, CH 100–199 / 200–299 pack support, TV file picker) plus a scheduled lineup-rebuild bot commit (`71c02d3`, 2026-11-15, one line in `web/data/lineup.json` — not a feature). **The APK release has NOT published** — verified 2026-11-15 evening: newest tag is still `v1.0.47`, latest release still v1.0.47 (Nov 8), no 1.18.x tag at all. The posted APK link still serves the Nov 8 build.

Work on a branch, open a PR per task (or one PR if tasks truly belong together). Nova validates before anything goes live; **do not merge** — merging is Mitchel's tap only.

## Task map — everything, in one place

| Task | Title | Status |
|---|---|---|
| 1 | Local hub: ZIP → place | OPEN |
| 2 | Local hub: Weather tab | OPEN |
| 3 | Local hub: News tab | OPEN |
| 4 | Local hub: Sports tab | OPEN |
| 5 | Local hub: Broadcasts tab | OPEN |
| 6 | Local hub: shell, ZIP flow, remote, styling | OPEN |
| 7 | More and varied cards (up-next + loading / ad) | OPEN — overlap check vs 1.16.0 first |
| 8 | Series / box-set loans | OPEN — decided 2026-11-08, never built |
| 9 | Page-flip sound: soft page | OPEN — decided 2026-11-08, small |
| 10 | Pack file picker in the Android app | **CLOSED — done in 1.18.1 (PR #27)** |
| 11 | Pack loader: play direct-link (`urls`) sources | OPEN |
| 12 | BUG: BACK doesn't exit the app | OPEN |
| 13 | BUG: "Send a pack to the TV" stalls | OPEN |
| 14 | BUG + retune: Sin City filters, yellow on Lite | OPEN |
| 15 | In-app pack browsing (TV + remote) | OPEN |
| 16 | Fast-forward and rewind UI | OPEN |
| 17 | Performance mode toggle (safe scope only) | OPEN |
| 18 | Classic commercial breaks | OPEN |

Suggested build order: **bugs first (12, 13, 14)**, then the Local hub (1–6), then direct links (11), then library (7, 8, 9), then player/TV (15, 16, 17, 18). Work in any order if a PR needs to move, but do not let new features jump ahead of the three bugs.

---

## PART A — BUGS FIRST

### Task 12 — BUG: pressing BACK multiple times does not exit the app

Found by Mitchel testing 1.18.0 on the TV on 2026-11-14. Pressing BACK repeatedly should exit the app (standard Android TV behavior); instead it does nothing / stays in the app. Find where BACK is intercepted, make repeated BACK exit cleanly, and make sure a single BACK still does the right thing inside the app first (back out of a menu / guide before exiting). Test on the TV path.

### Task 13 — BUG: "Send a pack to the TV" stalls — the TV stops answering

Found by Mitchel testing on 2026-11-14 ~20:08 CST (phone remote, Channels page, "Connected · via relay"). He sent `nostalgem-personal-packs-all (1).zip` (~45 KB) → "The TV stopped answering while it was sent. Send it again." He then tried a single small pack, `1980s-sci-fi-personal.json` → the same failure. Both fail identically, so this is not a size problem.

Mechanism, verified in main by Nova: the phone splits the file into 12,000-base64-char pieces (`FILE_CHUNK`, `web/js/link.js`), sends up to 4 at once, and the TV must ACK each piece (`web/js/main.js` `packFromPhone` → `link.sendTo({ t: "fileack", ... })`). The phone gives up after 20 s without all acks (`web/js/phone.js` `pumpPack`). A one-piece file failing means zero acks came back — the break is the ack/relay path, not the file.

Investigate, in this order: (1) whether the TV's relay connection had dropped — the phone's "Connected" only proves phone↔broker, and a dead TV side would look exactly like this; (2) whether the TV was on a stale cached web build without the `file` handler (unlikely — his TV showed 1.18.0 the same day, and the handler shipped in 1.13.0); (3) whether the relay/broker drops the TV's messages. Fix direction: make the send resilient — re-send unacked pieces instead of giving up at 20 s, re-knock/re-pair when the TV goes quiet mid-send, and show a useful diagnostic (on the phone: which piece stalled; on the TV: a toast when a file piece arrives, so Mitchel can tell whether the TV hears anything at all). Test on the TV path over the relay, not just direct: send the combined zip and a single pack, confirm the TV asks "Load these packs?" and the packs load. Report what you verified on the TV path vs the web path.

### Task 14 — Sin City filters: yellow renders black and white; widen the hue range

Found by Mitchel testing on the TV on 2026-11-14 ~20:10 CST. The Sin City looks don't filter the proper colors: **yellow is entirely broken, rendering black and white**. He asked to double-check and fine-tune them to capture a bit more range of hue.

**Mitchel's key diagnostic (2026-11-14 ~20:25 CST, live on the TV): the bug is tied to the performance limiter — on Full quality it works; on Lite it is just black and white.** That overturns the first guess (that lite runs the same math): the fault is in the lite path, not the mask rows. What Nova verified in main: on lite, the look runs on a small canvas (`web/js/main.js` `lookIsLite`/`applyLook`: `canvasLook.set({ canvas: "filter", filter: full })`), and `web/js/fxcanvas.js` draws the video through it with `s.filter = look.filter` — where `filter` is the combo CSS `url(#ng-look-pop-yellow)`. CSS `filter: url(...)` on an element works in Chromium (that is why Full works), but the canvas 2D context's `filter` is a different path and does not treat an SVG `url()` reference the same way — the prime suspect is that the TV WebView's canvas ignores (or half-applies) the `url()` filter, so the kept-color merge never happens in the lite draw and only the hard black-and-white survives. Confirm the mechanism on the TV WebView before fixing: reproduce lite pop-yellow → black and white, then check what `ctx.filter = "url(#...)"` actually does there.

Fix: make lite match full. Options, in order of preference: (1) do the pop in canvas pixels at lite size (draw the noir base plus the kept-color layer with the mask, instead of relying on `ctx.filter` with a `url()`), keeping the perf win; (2) if that is too much for this task, have lite fall back to the full element-level CSS filter for SVG pop looks only, and say plainly what it costs in frame rate. Either way, verify on the TV: Full and Lite must look the same for all six pop colors and for pairs, and the frame-rate watch must still protect the TV. The mask rows themselves (`web/js/looks.js`, `POP` table) also deserve the retune Mitchel asked for — muted film yellow currently needs R−B > 0.25 AND G−B > 0.25 at once, and the kept color's strength is the product of the two mask alphas, so real-world yellow fades to gray; orange (1, 0.5, 0) already passes as "yellow" because the rows never check that R and G are close. Once lite matches full, widen the hue window where it matters (muted yellows in) and narrow it where it doesn't (orange out — a real hue window around 60°, soft falloff instead of a hard product of ramps). Test on real Archive footage with strong yellows (a yellow taxi, road signs, desert sand in late light). Note: on YouTube channels the Sin City looks are grayscale-only by design (CSS can't keep one color) — this task is Archive only.

---

## PART B — THE LOCAL HUB (Tasks 1–6)

### Context

Mitchel's own words: his weather channel "sucks, it shows streams from months ago." The fix is live data, not another recording. He wants a **core function, not a pack**: the viewer types a ZIP code and the app shows local news, sports, weather, and free digital/OTA broadcasts for that area.

The worked example through this whole brief is **ZIP 77665 — Winnie, Texas**, Mitchel's home area (Beaumont–Port Arthur market). The hub ships defaulting to 77665 on first run, and any viewer can change it. Every endpoint, response, and station list below was verified live on 2026-11-14 against 77665 — build from these, do not re-derive them from memory.

NOSTALTV (a similar app) does its weather channel with live Open-Meteo data + jazz audio. That is a reference point, not a template: our hub is four tabs, not one channel, and it uses the same free Open-Meteo source plus NWS alerts, ESPN scores, and RabbitEars listings.

### Task 1 — ZIP → place (Zippopotam, Open-Meteo geocoding as fallback)

Primary: **Zippopotam.us** — free, no key, CORS open (`Access-Control-Allow-Origin: *`, verified live).

- `GET https://api.zippopotam.us/us/77665`
- Verified response: `{"country":"United States","country abbreviation":"US","post code":"77665","places":[{"place name":"Winnie","longitude":"-94.3395","latitude":"29.8157","state":"Texas","state abbreviation":"TX"}]}`
- Bad ZIP: `GET https://api.zippopotam.us/us/00000` → **404, body `{}`**. Treat any non-200 as "that ZIP didn't come back — check it and try again" and keep the previous ZIP.
- What it returns: place name, state + abbreviation, latitude, longitude. It does NOT return a timezone — get that from Open-Meteo (Task 2) or the geocoding fallback.
- US-only in v1. The API supports other countries (`/us/` → `/gb/`, etc.) but News/Sports/Broadcasts below are US-only, so a non-US ZIP gets weather only (see Task 6 fallbacks).

Fallback (city-name search, and timezone): **Open-Meteo geocoding** — free, no key, CORS open (`Access-Control-Allow-Origin: *`, verified with an Origin header).

- `GET https://geocoding-api.open-meteo.com/v1/search?name=Winnie&count=3&language=en&format=json`
- Verified response includes `results[].name`, `latitude`, `longitude`, `timezone` (`America/Chicago` for Winnie), `admin1` (Texas), `admin2` (Chambers), `country_code` (US), and `postcodes` (["77665"]). Use it when the viewer types a city instead of a ZIP, and to fill the timezone.

### Task 2 — Weather tab (Open-Meteo forecast + NWS alerts)

**Open-Meteo forecast** — free, no key, CORS open (`Access-Control-Allow-Origin: *`, verified with an Origin header). Exact URL (verified live for 77665 — full JSON returned):

```
https://api.open-meteo.com/v1/forecast?latitude=29.8157&longitude=-94.3395&current=temperature_2m,relative_humidity_2m,apparent_temperature,weather_code,wind_speed_10m,wind_direction_10m&hourly=temperature_2m,precipitation_probability,weather_code&daily=weather_code,temperature_2m_max,temperature_2m_min,precipitation_probability_max&temperature_unit=fahrenheit&wind_speed_unit=mph&precipitation_unit=inch&timezone=America%2FChicago&forecast_days=7
```

- Verified body (2026-11-14 19:45 CST): `current: {time, temperature_2m: 59.4, relative_humidity_2m: 52, apparent_temperature: 53.2, weather_code: 2, wind_speed_10m: 9.9, wind_direction_10m: 85}`, plus `hourly` arrays (temperature, precipitation_probability, weather_code) and `daily` for 7 days (weather_code, temperature_2m_max/min, precipitation_probability_max). Units come back in `current_units` / `hourly_units` / `daily_units` — read them, don't hardcode the degree symbol.
- Build the tab from exactly these fields: **Now** (temp, feels-like, humidity, wind speed + direction, condition words), **Next hours** (temp + rain chance per hour), **7-day** (high/low, rain chance, condition per day). Use the `timezone` from the response for all displayed times.
- **WMO weather_code → words** (ship this table in the code, it is the standard mapping): 0 clear sky · 1 mainly clear · 2 partly cloudy · 3 overcast · 45/48 fog · 51/53/55 drizzle light/moderate/dense · 56/57 freezing drizzle · 61/63/65 rain slight/moderate/heavy · 66/67 freezing rain · 71/73/75 snow slight/moderate/heavy · 77 snow grains · 80/81/82 rain showers slight/moderate/violent · 85/86 snow showers · 95 thunderstorm · 96/99 thunderstorm with slight/heavy hail.
- **Rate limit — read this.** Open-Meteo's free tier has a daily per-IP request cap. The shared egress IP used for this research hit it (`429 "Daily API request limit exceeded"` on a curl fetch; the forecast body above was verified via a separate fetch route). From a viewer's own home IP the cap is generous, but the hub must still cache: fetch weather **once when the hub opens and at most every 30 minutes after**, never per channel tune and never on a timer while the hub is closed. If a fetch 429s, show the last cached data with its timestamp and a plain "weather will refresh shortly" note — never a blank tab.
- **What Open-Meteo does NOT cover:** no radar, no alerts, no severe-weather warnings. Alerts come from NWS below; radar is out of scope for v1 (link out instead — see below).

**NWS alerts** — free, no key, CORS open (`Access-Control-Allow-Origin: *`, verified live). This matters in Southeast Texas — hurricane country — and it is what makes the tab trustworthy when a storm is coming.

- `GET https://api.weather.gov/alerts/active?point=29.8157,-94.3395`
- Verified live: 200 with a real FeatureCollection containing an active alert for the Winnie point at check time.
- **You MUST send a User-Agent header identifying the app** (NWS asks for one). Use something like `NostalGem/1.18 (https://github.com/TheUpDoge/Nostalgem)` — no contact email in the header.
- Show an alerts banner at the top of the Weather tab when any alert is active: `properties.event` + `properties.severity` + `properties.headline`, with the full `properties.description` / `properties.instruction` expandable. Alert text can be long — truncate with "more" expansion, don't dump the whole thing on the screen. No active alerts → no banner, nothing special.
- Also verified via `GET https://api.weather.gov/points/29.8157,-94.3395`: NWS office Lake Charles (`LCH`, gridpoint `17,76`), county Jefferson `TXC245`, forecast zone `TXZ615`, radar station `KHGX`. Use the `radarStation` from the point response for the radar link-out.
- **Radar is a link-out, not an embed, in v1.** Link to the NWS radar page for the `radarStation` from the point response. There is no free embeddable radar-tile API without a key, and that is an honest limit, not a bug to work around.

### Task 3 — News tab (link-outs + RSS + Archive national fallback)

There is no free, keyless, embeddable live local-news stream for Beaumont. Do not promise one. The tab is: the market's stations as link-out cards, RSS headlines where a feed actually parses, and Archive national news as playable fallback.

**Link-out cards (worked example, 77665 — Beaumont–Port Arthur market, Nielsen rank ~142–143, ~170,420 TV households):**

| Station | Channel | Network | Site |
|---|---|---|---|
| KFDM | 6.1 | CBS (CW 6.2, Fox 6.3) | kfdm.com |
| KBMT | 12.1 | ABC (NBC 12.2, Cozi 12.3, MeTV 12.4) | 12newsnow.com |
| KBTV-TV | 4 | Dabl (Fox moved to KFDM 6.3 in 2021) | — |
| KITU-TV | 34 | TBN | — |
| KUIL-LD / KGEW-LD | — | ind. / Telemundo 33.1 | — |

- Each card opens the station's site in the TV browser through the existing link-out path (same as CH 555/777). There is **no PBS station in this market** — do not list one.
- For other ZIPs the card list comes from the market lookup in Task 5 (RabbitEars market data) — the app does not ship a station table for every US market; the Broadcasts tab's market list is the source of truth, and the News tab shows the full-power stations from it with their network affiliations.

**RSS headlines (verify at build time — partially verified, see below):**

- `https://www.12newsnow.com/rss` → **200** (endpoint responds; the body was NOT parsed in this pass — confirm it parses as RSS/Atom before wiring it in).
- `https://kfdm.com/rss` → **307 redirect**, destination not followed — treat as unverified, do not wire it in until confirmed.
- Rule: a feed that doesn't parse cleanly is dropped silently from the tab (link-outs + Archive carry it). Do not burn the build on feed parsing — see the scope cut at the bottom.

**Archive TV News — national fallback, playable in-app via the existing Archive player:**

- `GET https://archive.org/advancedsearch.php?q=collection%3Atvnews&fl%5B%5D=identifier&fl%5B%5D=title&fl%5B%5D=date&rows=25&sort%5B%5D=date+desc&output=json`
- The `tvnews` collection holds ~4.7M items — mostly national cable (CNN, MSNBC, FOX News, C-SPAN) and a few big-market stations. Verified: `identifier:KFDM*` returns only **12 items, all old/scattered recordings** (1985–86, one Oct 2024 newscast) and `identifier:KPRC*` (Houston NBC) returns **15 items, all 1984–87**. There is **no live or recent Beaumont or Houston local news on the Archive**. Present this row honestly as "National news recordings" — never as local news.

**Unverified — do NOT promise these until checked from a real browser:**

- **NewsON** (newson.us) and **Haystack News** (haystack.tv) could not be fetched from this research environment (both domains blocked by the fetch policy — not a judgment on the services). They are candidates for free local-news streams, but Claude must verify from a real browser that they play without an account before the tab links to them. If they check out, they become link-outs alongside the station sites.
- **Local Now** (`https://www.localnow.com/`) — verified the site loads; it is a free FAST service with national news channels plus local-station streams from other markets (no Beaumont station was visible in the fetched rows). No public embed API was observed — **link-out only** (`localnow.com`), never an embed.

### Task 4 — Sports tab (ESPN free site API + a static metro table)

**ESPN site API** — free, no key, CORS open (`Access-Control-Allow-Origin: *`, verified on the NFL scoreboard). All of these returned 200 live:

```
https://site.api.espn.com/apis/site/v2/sports/football/nfl/scoreboard
https://site.api.espn.com/apis/site/v2/sports/baseball/mlb/scoreboard
https://site.api.espn.com/apis/site/v2/sports/basketball/nba/scoreboard
https://site.api.espn.com/apis/site/v2/sports/hockey/nhl/scoreboard
https://site.api.espn.com/apis/site/v2/sports/soccer/usa.1/scoreboard
https://site.api.espn.com/apis/site/v2/sports/football/college-football/scoreboard
```

- Teams list (same pattern, verified): `https://site.api.espn.com/apis/site/v2/sports/football/nfl/teams` — and the per-sport equivalents. The college-football teams list at `?limit=1000` returns 763 teams.
- **How "nearest teams" works — there is no ESPN "nearest team" endpoint.** The app ships a small static metro table (state/market → teams) and picks the metro for the viewer's ZIP. Do not compute distances and do not call a geolocation API for this.
- **Worked example for 77665 (Houston metro, ~80 miles west):** Houston Texans (NFL), Houston Astros (MLB), Houston Rockets (NBA), Houston Dynamo (MLS). Secondary: New Orleans Saints / Pelicans. College: **Lamar Cardinals — NCAAF, ESPN team id 2320** (verified in the teams list; FCS, Southland Conference — scores show on game days, coverage is thinner than FBS, say so in the UI if a game has no data).
- The tab shows, for each of the viewer's teams: today / most recent score (filter the league scoreboard by team id — do not assume a per-team schedule endpoint; that path was not verified), plus a link-out to the team's ESPN page for detail. Fetch the scoreboard once when the tab opens, not per tune.
- **High-school sports are NOT covered** — there is no free source for them. Say so plainly in the tab ("Pro + college scores — no high-school source") rather than showing an empty list.
- Offseason honesty: a league out of season returns an empty scoreboard — show "Season starts [date]" from the scoreboard's `season` object, not "no games" as if something broke.

### Task 5 — Broadcasts tab (RabbitEars link-out + a shipped market table)

This tab answers "what's on antenna at this ZIP" — a **list**, not playable streams. Live local broadcast streams are not freely available; do not pretend otherwise.

**RabbitEars — link-out only (this is load-bearing, read carefully):**

- Correct URL: `https://www.rabbitears.info/search.php?request=zip_search&zipcode=77665&miles=60`
- **The parameter is `zipcode`, not `zip`.** Using `zip=77665` silently returns the wrong market — verified the hard way in research (it returned Birmingham, AL stations). Do not "fix" this by guessing; the form field on the site is literally `name="zipcode"`.
- Verified live with the right param: the results list KFDM, KBMT, KBTV, KITU, KUIL and Houston stations for 77665, with virtual channel, RF channel, network, community of license, distance in miles, and direction.
- **RabbitEars sends NO CORS header** (checked with an Origin header — no `Access-Control-Allow-Origin` at all). The app **cannot** fetch these results from the browser. The tab therefore links out to the results URL above, which opens in the TV browser — the page is server-rendered HTML and works without JavaScript (verified via text fetch). Never scrape it, never proxy it.
- The tab also ships a small static table for the viewer's market (from the same RabbitEars data, recorded at build time) so the list is visible without leaving the app. Worked example for 77665, 60-mile radius — full-power + major low-power:
  - KFDM 6.1 CBS · 6.2 CW · 6.3 Fox — Beaumont
  - KBMT 12.1 ABC · 12.2 NBC · 12.3 Cozi TV · 12.4 MeTV — Beaumont
  - KBTV-TV 4.x Dabl — Port Arthur
  - KITU-TV 34.x TBN — Beaumont
  - KGEW-LD 33.1 Telemundo — Port Arthur/Beaumont
  - KUIL-LD — Beaumont
  - Plus Houston signals receivable at the fringe (list with distance + direction from the RabbitEars result, marked "fringe — needs a good antenna").
- The static table is per-market data recorded at build time, not a live fetch. For ZIPs outside the shipped markets, the tab shows the RabbitEars link-out and a "look up your antenna" card — never an empty list and never invented stations.

**Free FAST local options (link-outs, not embeds):** Local Now (`localnow.com`, verified loads — see Task 3). NewsON / Haystack — unverified, same rule as Task 3.

### Task 6 — The hub itself (shell, ZIP flow, remote, styling, fallbacks)

- **Where it lives: a new top-level section, NOT a channel.** Add a Menu entry "📍 Local" at the same level as the guide, Video Club, and Reading Room. Channels are scheduled video on the shared clock; Local is live data + links, so it must not take a dial number and must not appear in the guide as a channel. The old recorded-weather channel should stop pretending to be live weather — recommendation: wire its entry to open the hub (Mitchel to confirm; if he prefers, it can stay as clearly-labeled vintage weather films).
- **ZIP storage: on-device only.** `localStorage`, key `nostalgem_local_zip`. Nothing leaves the device, no account, no server. First run ships defaulting to **77665** (Mitchel's home ZIP — this is his instruction, not a placeholder). Changing it re-resolves Tasks 1–2 and re-renders all four tabs.
- **ZIP entry, two paths:** on the TV, an on-screen entry using the existing numpad/directional input (5 digits, US ZIPs only in v1); on the **phone remote** (`remote.html`, `js/remote.js`), a ZIP field + save button sent over the existing relay/direct connection — the remote already has a keyboard (Task 1 / 1.13.0), reuse it, don't build a second input method. Typing on the phone is the path Mitchel will actually use.
- **Tabs: Weather / News / Sports / Broadcasts.** D-pad: left/right moves between tabs, up/down moves between cards, BACK closes the hub back to the channel. Fetch once per tab per open (weather cached 30 min — see Task 2); no background polling while the hub is closed.
- **Styling: keep it retro.** Reuse the guide's station-card look and the per-channel card styling — big text readable from the couch, CRT-safe, same fonts and colors as the rest of the set. The weather tab gets the Open-Meteo condition words + the WMO icons; the NWS alert banner uses the app's existing warning styling, not a new design language.
- **Fallbacks (every external fetch gets a 10-second timeout and a plain-English failure card — never a blank tab, never a stack trace):**
  - Bad ZIP → "That ZIP didn't come back — check it and try again", keep the previous ZIP.
  - Non-US ZIP → weather still works (Open-Meteo + Zippopotam are global); News / Sports / Broadcasts show "US only for now" cards.
  - Offline / fetch fails → show the last cached data with its "last updated" stamp + a "no connection right now" note.
  - A tab whose source returns nothing usable → one honest line ("No scores today — season starts [date]" / "No active alerts"), not an error dump.

**Local hub — out of scope (explicitly, do not build these in this PR):**

- Radar embedded in the app (link-out only — Task 2).
- Live local TV streams (no free, legal, keyless source exists — the Broadcasts tab is a list, not a player).
- High-school sports (no free source).
- Any keyed API as a requirement (NewsAPI, Gracenote, or any paid tier). A keyed source may only ever be an *optional user-supplied key*, and v1 needs none — do not add a key field.
- Scraping or proxying RabbitEars (no CORS — link-out only).
- Anything that touches channel packs (separate work, running in parallel) or the dial plan (built-ins 1–29, viewer packs 30–49, YouTube sub-channels 50–90, additional packs 100+).
- Gamepad support for the hub (the app's gamepad.js covers games; the hub is D-pad + remote).

**Local hub — tests:**

- ZIP flow: 77665 resolves to Winnie, TX (lat/lon + timezone); 00000 shows the bad-ZIP card and keeps the previous ZIP; changing the ZIP re-renders all four tabs.
- Weather: the 77665 forecast URL returns current + hourly + 7-day and the tab renders all three; the WMO table maps codes 0/2/61/95 to words; an active NWS alert renders the banner (mock one if none is active at test time); a 429/failed fetch shows cached data with its timestamp.
- News: link-out cards open the station sites in the TV browser; the RSS feed is only wired in if it parses; the Archive national row plays through the existing Archive player.
- Sports: the scoreboard endpoints return 200 for all six leagues; the 77665 mapping picks Houston teams + Lamar (id 2320); an out-of-season league shows its season start date.
- Broadcasts: the RabbitEars link-out opens the correct ZIP results page (check the URL carries `zipcode=`, not `zip=`); the shipped 77665 station table matches the RabbitEars result.
- Remote: typing a ZIP on the phone remote updates the TV's stored ZIP and re-renders the hub.
- Report what you verified on the TV path vs the web path, and what still needs Mitchel.

**Local hub — recommended scope cut:** If the per-station RSS feeds don't parse cleanly at build time, **cut RSS headlines from the News tab** and ship link-outs + Archive national only. Do not burn the build on feed parsing — the tab is complete without it. (Second cut, only if forced: drop the shipped static market table and make Broadcasts a pure RabbitEars link-out — but try the table first, it is what makes the tab usable without leaving the app.)

---

## PART C — DIRECT LINKS (Task 11)

### Task 11 — Teach the pack loader to play direct-link (`urls`) sources

Context: Mitchel asked for a tool so users can build their own channel packs, and Nova built the **Pack Builder** (workspace: `ts-spaces/channel-pack-builder/index.html`). It exports standard pack JSON, and it now supports a second source type per channel: **direct links**. A channel entry can carry `sources: [{ urls: [...] }]` alongside the existing `sources: [{ items: [...] }]` Archive IDs. The builder's example pack proves the shape — CH 144 "Open Movies — via URL" is built entirely from direct links:

- `https://archive.org/download/BigBuckBunny_124/Content/big_buck_bunny_720p_surround.mp4`
- `https://archive.org/download/ElephantsDream/ed_1024_512kb.mp4`

**The app loader does not read the new field yet.** A channel mixing Archive items and links loads, but the links sit there ignored; a links-only channel does not load at all. That is the gap this task closes. The builder side is done — this task is app-side only.

In the pack loader / channel player (whatever owns `sources[].items` today — likely `web/js/packs.js` and the player in `web/js/main.js`; find the real owners, don't guess):

1. **Read `sources[].urls`.** Each entry is a full URL to a playable file: `.mp4`, `.webm`, or an `.m3u8` HLS stream. Treat each URL as one program on that channel, in rotation with the channel's Archive items — mixed channels rotate Archive items and links together.
2. **Links-only channels must load.** A channel whose sources are only `urls` (CH 144 in the example pack) must tune, show in the guide, and play, exactly like an Archive channel. Today it does not load at all.
3. **A dead link must not kill the channel.** Validate each URL at load (HEAD / fetch where the player allows); skip dead, login-only, or short-lived links and keep the rest of the channel playing. Log which were skipped so the pack author can see it.
4. **Page URLs are NOT playable as pack entries — skip them cleanly.** YouTube and Vimeo *page* links (`youtube.com/watch?v=…`, `vimeo.com/…`) cannot play through the pack player; those belong in the sub-channel player, not in packs. The loader must skip them at validation (never hang or error the channel) and the skip reason should be visible. Note: the Pack Builder's "Direct links" textarea placeholder currently shows a `youtube.com/watch?v=…` example — flag that as a builder-side fix for Nova (drop the YouTube example from the placeholder), don't try to make the loader play it.
5. **Keep the existing rules.** `items` (Archive IDs) behave exactly as today. The `urls` field is additive — no change to pack format version, channel-number rules (30–49, 100–299), or the validator's other checks.
6. **Tests:** load the builder's example pack (CH 142 Archive, CH 143 Archive, CH 144 links-only) on web and confirm CH 144 tunes and plays both links; a mixed channel rotates both kinds; a pack with one dead URL plus good ones still loads with the dead one skipped; a pack with a YouTube page URL in `urls` loads with that entry skipped, not the channel. Report what you verified on the web path vs the TV path.

---

## PART D — LIBRARY & CARDS (Tasks 7, 8, 9)

### Task 7 (RESTATED, still open) — More and varied cards (up-next + loading / ad cards)

Mitchel's "cards" are the **up-next cards and the loading-screen / ad cards** (the interstitials between programs and while a channel loads). Make more of them, and vary them: different looks per genre / channel family (horror, sci-fi, kids, westerns, music…), not one card for everything. Keep the existing timing (the 8-second station breaks) and the sponsor-card behavior for YouTube pre-roll ads. This is design + the selection logic — the cards are the app's face between shows, so they should feel like the channel they're on.

**Overlap check first:** 1.16.0 shipped "Cards with character" — up-next and loading cards in each channel's own style, words in `data/cards.json`. Before building, read what 1.16.0 did and report what is already there vs what is still missing. This task is the variety on top of that: more card designs per genre/family, and the selection logic that picks the right one — not a redo of 1.16.0. If the per-channel styling already covers a family well, say so in the PR and move on to the next family.

### Task 8 (DECIDED 2026-11-08, never built) — Series / box-set loans

The Video Club stocks feature films only (≥40 min), so series have no shelf at all — sitcoms (CH 47–49), anime series (CH 37–39, 41–42), Saturday Morning (CH 8), Rerun City (CH 11), Game Night (CH 12). Mitchel chose to build a new loan kind instead of leaving series live-only: a **box set** — a whole series checked out as one loan, not a tape.

Design and build it: a box set lives in the Club alongside tapes (its own presentation — do not dress it up as a tape box), it plays episodes in order with resume where the viewer left off, and it follows the library's loan spirit (the current limits are 2 tapes / 3 days, 3 books / 2 weeks — propose the box-set limits in the PR: how many out at once, how long, and whether a box set counts against the tape limit). The series come from the series channels and pack channels; the episodes are the Archive items those channels already carry. Keep the tastefulness line and the dial plan out of this — no new channels, no new content, just the loan kind. Tests: checkout / return / resume for a box set, and the loan-limit behavior. Report the proposed limits and the resume behavior in the PR for Mitchel's sign-off.

### Task 9 (DECIDED 2026-11-08, small) — Page-flip sound: soft page

Change the Reading Room's page-flip sound to the **soft page** variant. The current sound (`web/js/ui/reader.js`) is a synthesized 0.22s noise burst, bandpass sweep 2600→1100 Hz, Q 0.7, decay (1-t)^1.6, gain 0.09. The replacement, same synthesized approach (no new assets, no recorded sample):

- **Duration 0.15s, bandpass sweep 1200→800 Hz, Q 0.7, decay envelope (1-t)^2, gain low** — at or a touch below the current 0.09; the point is subtle. (Nova's demo clip of this sound is `flip-soft.mp3` if Mitchel shares it — the clip is turned up for listening; the in-app gain stays low.)
- Keep the existing sound on/off preference working exactly as it is.

Small task — fold it into your next batch. Test: the flip still plays the new sound and still respects the sound setting.

---

## PART E — PLAYER & TV (Tasks 15, 16, 17, 18)

### Task 15 — In-app pack browsing: the TV and remote pull the pack list from #add-ons

Nova built the Pack Builder (a page where anyone can make a pack), and the packs live in the NostalGem Discord #add-ons channel as examples. The next step is the other half: **browse and load packs from inside the app** — the TV (and the phone remote) shows the pack list, and the viewer picks one to load, without leaving the app or copying files by hand.

Design and build it, but read the constraint first: **personal packs must never enter the public repo.** The packs live in Discord #add-ons as attachments, and the repo stays clean — so the TV cannot fetch the pack list from the repo. Propose the source in the PR and build only what Mitchel signs off on. The shape Nova has in mind: a small index (channel numbers, names, program counts — the same facts as `PACK-INDEX.md`) hosted outside the repo, on Mitchel's own Neocities site, which the app fetches and lists; picking a pack loads it the same way Paste does today. Alternatives are welcome if they keep the repo clean and the list fresh when new packs land in #add-ons. The list must stay in sync with what is actually in #add-ons — say in the PR how it stays fresh (hand-updated index vs generated from the channel) and who updates it.

Keep the existing load paths working (Paste, Send-a-pack from the phone, file picker). This adds browsing; it does not replace anything. TV hardware is the perf gate: the list must be light to render and scroll on the TV.

### Task 16 — Fast-forward and rewind UI

There is no fast-forward or rewind UI in the player today. Verified in main: the only "Rewind" is the Video Club's tape-return (`main.js` `rewindTape` — returning a tape, not playback); the player already supports playback speed (`player.js` `playbackRate` / `defaultPlaybackRate`) but nothing exposes it; seeking exists only for phone-sent items (`sentSeek`). Build visible FF/RW controls for the TV player, with the same controls on the phone remote.

Design, then build: FF steps through speeds (2x / 4x / 8x, tap to step up, tap play to resume normal speed); RW steps backward in jumps (10s / 30s — true reverse playback is not possible in the video element, so RW is stepped seek-back, and the UI must say so plainly by how it behaves, not by promising reverse motion). Show the speed and the position on screen while shuttling, and make it work from the TV remote's d-pad/arrows as well as on-screen buttons. Clamp to the current program — and name the schedule question in the PR, don't silently decide it: live channels run on a shared clock, so scrubbing puts the viewer behind the clock; propose how FF/RW behaves at the program boundary and how the viewer gets back to live (a "back to live" action). Keep the shared clock as the default; scrubbing is a local offset, not a new schedule. Test on the TV path: FF through a program, RW jumps, resume, and back-to-live all work from the remote, and the phone remote's controls match.

### Task 17 — Performance mode toggle (TV app, safe scope only)

Mitchel's ask: a performance mode for the TV app — free up memory and processor headroom. Build it, but ONLY inside what a sideloaded app is actually allowed to do. These are hard platform limits, not missing features — do not work around them with root, ADB, shell commands, or hidden APIs:

- **DO NOT build:** force-stopping other apps, clearing other apps' caches, killing other apps' background processes, or overclocking. Force-stop and cross-app cache clearing need system-only permissions; since Android 14, `killBackgroundProcesses()` only works on the app's own processes — passing another app's package is ignored by the system; overclocking needs root and a custom kernel and can damage the TV. None of these belong in the app, ever.
- **DO build — "Performance mode" toggle (Menu → Performance mode), which does all of these together, and shows what it did:**
  1. Request sustained performance mode (`Window.setSustainedPerformanceMode(true)`) — the real API: it asks the platform to hold CPU/GPU at the highest sustainable frequencies and avoid thermal throttling. It is a hint, OEM-dependent, and it trades peak bursts for consistency — say so in the UI, don't promise a speed boost.
  2. Clear the app's OWN caches (WebView cache, the app's own cache dir) and drop the app's own memory footprint.
  3. Engage the lightest rendering the app already has (the 1.15.0 lite path: lite filters, 80-col ASCII, 10×/s new picture) while the toggle is on, even if the user had Full selected — and restore their settings when it is turned off.
  4. A "What's using memory" screen that lists the other apps running on the TV and, for each one, a button that opens THAT app's system settings page so the viewer can force-stop it themselves. The app guides; the user acts. No silent killing.
- Keep the toggle off by default, remember the setting per TV, and smoke-test it on a real TV (no baseline numbers needed — just confirm the toggle works and the app stays smooth).

### Task 18 — Classic commercial breaks

Mitchel's idea: old, cool, nostalgic commercials playing here and there between programs. Build it as a break kind, not a channel: occasionally, instead of the 8-second up-next station break, the app runs a full vintage commercial (30–60s) with a "Commercial Break" card, then returns to the schedule. The commercials come from the Prelinger Archives on the Internet Archive (public domain — verify each title's PD status before shipping it; Claude picks a starter set of well-known, clean, fun spots, 1950s–80s, and lists every ID in the PR).

Design and build: how often a commercial break appears (propose the cadence in the PR — e.g. every Nth break, never twice in a row, never interrupting a program), a setting to turn commercial breaks off (default: on, since this is the point of the feature), and the break respects the viewer's picture and sound settings. Keep the 8-second up-next card as the normal break — commercials are the occasional spice, not the default. These breaks are content, not advertising — nobody pays to place a commercial in them (see Standing rules: money). A Classic Commercials pack channel already exists (CH 213, in Discord #add-ons) — the break feature should be able to draw from the same Prelinger pool; propose in the PR whether breaks pull from the built-in starter set, the pack channel, or both. TV hardware is the perf gate. Test: breaks appear at the proposed cadence, the schedule resumes correctly after a break, the off setting is respected, and the commercial itself plays cleanly on the TV path.

---

## CLOSED & HELD — read before building

- **Task 10 — CLOSED.** The pack file picker is done in code: 1.18.1 (PR #27, merged 2026-11-14) implements `onShowFileChooser` in MainActivity.kt. It needs a fresh APK before the TV sees it (see release note). Do not rebuild it.
- **2026-11-08 order, Tasks 1–7 — DONE** via 1.18.0 (PRs #24/#25): Send to TV, phone Mouse page + pack forwarding, 4:3 mode, TV performance, casting spec (Option B shipped), cards with character, library rows. Task 7's remainder lives on as Task 7 above.
- **Casting: do NOT build a Chrome Cast button.** Mitchel asked about a one-tap Cast button. That is the already-decided **Option A (Google Cast), rejected 2026-11-08** in favour of **Option B — "Send to TV"** (phone tells NostalGem what to play over the remote link), which shipped in 1.18.0. A Cast button that hands the stream to Chrome/Chromecast would replace NostalGem on the TV instead of playing inside it, is Chrome-only, and needs Google's SDK + a paid developer registration. If Mitchel wants one-tap casting, the path is a Send-to-TV shortcut inside the remote — **that is a decision for Mitchel, not a build task here.** Do not implement Google Cast.
- **Ronin Warriors in main: DECIDED NO (2026-11-15).** Mitchel chose to leave it as the Archive pack (CH 211) + Send to TV. Do not add a Ronin Warriors YouTube sub-channel to the shipped lineup.
- **The 14 copyrighted titles stay in the built-ins** (Mitchel's call, 2026-11-14 — the pack separation is what keeps it clean). Do not re-remove them.
- **For Nova, not Claude:** the Pack Builder's "Direct links" textarea placeholder currently shows a `youtube.com/watch?v=…` example — Nova will drop the YouTube example from the placeholder. Do not try to make the loader play it (see Task 11.4).

## Standing rules

- **Money: none in the mix.** The app stays free — no paywalls, no advertising for revenue, no in-app purchases, no donation button that pays Mitchel. If any support/donate link is ever added, the Internet Archive's donate link comes first, and Mitchel personally expects and wants $0 from the app. The commercial breaks in Task 18 are vintage public-domain content, not paid ad slots — nobody pays to place one.
- Branch + PR per task (or one PR if tasks truly belong together). **Do not merge.**
- Tests must pass (unit + browser suites). Add browser-test coverage where a task adds behavior.
- No new runtime dependencies — the app is zero-deps, ES2018-clean.
- The public repo stays clean: built-in channels are public-domain only. Personal packs (90 packs, 121 channels, 4,764 programs, incl. Mitchel's wife's CH 100–101) live separately in Discord #add-ons as examples — never copy pack content into the repo.
- TV hardware is the perf gate: cap canvas size and pixel ratio on the TV path, measure before/after, report what you verified on the TV path vs the web path.
- Report back per task: what changed, what you verified (tests, and what you could or couldn't check on a real TV), and what still needs Mitchel.
- Crew shape: Claude builds, Nova validates before anything goes live. Mitchel merges.

## Release note (Mitchel's action, not Claude's)

The APK needs the Android release workflow re-run with **"Publish a release" ticked**, then confirm a v1.18.x tag appears on GitHub. Until then the posted APK link serves the Nov 8 build (v1.0.47). A holding note ("web version is 1.18.1 right now — the new TV app download is still publishing") was drafted for Discord #whats-on and the Facebook post.

---

*Ultimate order assembled by Nova 2026-11-15 from the three 2026-11-14 orders, with Task 10 closed (1.18.1), pack counts updated to 90 packs / 121 channels / 4,764 programs, the Ronin Warriors decision (2026-11-15) recorded, and repo state re-verified live the same evening (main 1.18.1 + lineup bot commit; newest tag v1.0.47). Revised same evening ~21:53: mission + funding principle added (header + standing rules); Task 18 clarified — breaks are content, not paid placements.*
